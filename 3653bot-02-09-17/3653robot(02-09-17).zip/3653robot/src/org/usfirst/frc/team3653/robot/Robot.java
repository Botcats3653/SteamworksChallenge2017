
package org.usfirst.frc.team3653.robot;

import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.vision.VisionThread;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.cscore.UsbCamera;
import org.opencv.core.Rect;
import org.opencv.imgproc.Imgproc;
import org.usfirst.frc.team3653.robot.commands.VisionCommand;
import org.usfirst.frc.team3653.robot.subsystems.ExampleSubsystem;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {

	public static final ExampleSubsystem exampleSubsystem = new ExampleSubsystem();
	public static OI oi;
	private ADXRS450_Gyro gyro;
	private XboxController player1;
	public static RobotDrive drive;
	private Relay camLED;
	private VisionThread visionT;
	public static double imgCenter = 0.0;
	public static final Object imgLock = new Object();
	public static final int RES_WIDTH = 320;
	public static final int RES_HEIGHT = 240;
	
	

	Command autonomousCommand;
	SendableChooser<Command> chooser = new SendableChooser<>();

	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		oi = new OI();
		camLED = new Relay(0);
		gyro = new ADXRS450_Gyro(SPI.Port.kOnboardCS0);
		UsbCamera camera =  CameraServer.getInstance().startAutomaticCapture(0);
		
		camera.setResolution(RES_WIDTH, RES_HEIGHT);
		
		visionT = new VisionThread(camera, new GripPipeline(), pipeline -> {
			if (!pipeline.filterContoursOutput().isEmpty()){
					Rect r = Imgproc.boundingRect(pipeline.filterContoursOutput().get(0));
					synchronized (imgLock){
						imgCenter = r.x + (r.width/2);
					}
				}
			});
		visionT.start();
		
		SmartDashboard.putData("Auto mode", chooser);
		LiveWindow.addSensor("Vision", "gyro", gyro);
		player1 = new XboxController(0);
		drive = new RobotDrive(0,1,2,3);
		
		//SmartDashboard.putData("Gyro", gyro);
		//chooser.addDefault("Default Auto", new ExampleCommand());
		// chooser.addObject("My Auto", new MyAutoCommand());
	}

	/**
	 * This function is called once each time the robot enters Disabled mode.
	 * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
	 */
	@Override
	public void disabledInit() {

	}

	@Override
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * getString code to get the auto name from the text box below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the
	 * chooser code above (like the commented example) or additional comparisons
	 * to the switch structure below with additional strings & commands.
	 */
	@Override
	public void autonomousInit() {
		//VisionCommand vision = new VisionCommand();
		autonomousCommand = chooser.getSelected();
		camLED.set(Relay.Value.kForward);
		//vision.execute();
		/*
		 * String autoSelected = SmartDashboard.getString("Auto Selector",
		 * "Default"); switch(autoSelected) { case "My Auto": autonomousCommand
		 * = new MyAutoCommand(); break; case "Default Auto": default:
		 * autonomousCommand = new ExampleCommand(); break; }
		 */

		// schedule the autonomous command (example)
		if (autonomousCommand != null)
			autonomousCommand.start();
	}

	/**
	 * This function is called periodically during autonomous
	 */
	@Override
	public void autonomousPeriodic() {
		Scheduler.getInstance().run();
		synchronized (Robot.imgLock){
			this.imgCenter= Robot.imgCenter;
		}
		double turn = imgCenter - (Robot.RES_WIDTH/2);
		double turnAngle = (turn*68.5/Robot.RES_WIDTH);
		System.out.println("Turn to Image Center "+ turn);
		System.out.println("TurnAngle to Image Center "+ turnAngle);
		System.out.println("Image Center "+ imgCenter);	
		
	}

	@Override
	public void teleopInit() {
		// This makes sure that the autonomous stops running when
		// teleop starts running. If you want the autonomous to
		// continue until interrupted by another command, remove
		// this line or comment it out.
		if (autonomousCommand != null)
			autonomousCommand.cancel();
	}

	/**
	 * This function is called periodically during operator control
	 */
	@Override
	public void teleopPeriodic() {
		
		if (player1.getAButton()==true){
			camLED.set(Relay.Value.kForward);
		}
		if (player1.getBButton()==true){
			camLED.set(Relay.Value.kOff);
		}
		Scheduler.getInstance().run();
    		LiveWindow.run();
		drive.mecanumDrive_Cartesian(player1.getY(GenericHID.Hand.kRight), player1.getX(GenericHID.Hand.kRight), player1.getX(GenericHID.Hand.kLeft), gyro.getAngle());
	}

	/**
	 * This function is called periodically during test mode
	 */
	@Override
	public void testPeriodic() {
		
    	while(isTest()&& isEnabled()) {
    		double angle = gyro.getAngle();
    		LiveWindow.run();
    		System.out.println(angle);
    		Timer.delay(1);
    	}
	}
}
