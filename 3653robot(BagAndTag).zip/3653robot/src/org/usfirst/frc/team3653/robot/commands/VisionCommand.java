package org.usfirst.frc.team3653.robot.commands;
//import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.vision.VisionThread;
import org.opencv.core.Rect;
import org.opencv.imgproc.Imgproc;
import org.usfirst.frc.team3653.robot.GripPipeline;
import edu.wpi.cscore.UsbCamera;
import edu.wpi.first.wpilibj.CameraServer;
import org.usfirst.frc.team3653.robot.Robot;
import org.usfirst.frc.team3653.robot.RobotMap;
import java.lang.Thread;

public class VisionCommand extends Command{
	double  imgCenter;
	double rot;
	boolean finished;
	public static final Object imgLock = new Object();
	VisionThread visionT;
	UsbCamera camera;
	Rect r1;
	Rect r0;
	int resh=RobotMap.RES_HEIGHT;
	int resw=RobotMap.RES_WIDTH;
	
	public boolean checkAspectRatio(Rect r){
			if (r.width==0){return false;}
			double ratt = (double)(r.height)/r.width;
			return 2.0 <= ratt && ratt <= 3.0;
		}
	
		public boolean checkSpacing(Rect r0, Rect r1){
			if (r0.height==0){return false;}
			double ratio = (Math.abs((double)(r0.x-r1.x)/r0.height));
			return 1.20<=ratio && ratio<=2.0;
			
		}
		
	public VisionCommand() {
		
		finished = false;
	}
	public void initialize() {
		
		UsbCamera camera =  CameraServer.getInstance().startAutomaticCapture(0);
		camera.setResolution(resw, resh);
		camera.setFPS(10);
		
		visionT = new VisionThread(camera, new GripPipeline(), pipeline -> {
			if (pipeline.filterContoursOutput().size()==2){
					Rect r0 = Imgproc.boundingRect(pipeline.filterContoursOutput().get(0));
					Rect r1 = Imgproc.boundingRect(pipeline.filterContoursOutput().get(1));
					
					if (checkAspectRatio(r0)&& checkAspectRatio(r1)&&checkSpacing(r0,r1)){
							synchronized (imgLock){
							imgCenter = ((r0.x+r1.x+r1.width)/2);
						}
					} 
					
				}
			});
		visionT.start();
		
		
	}
	
	public void execute() {
		imgCenter=-1;
		rot = .5;
		while (imgCenter < 0){
			synchronized (Robot.imgLock){
				if (Robot.imgCenter>=0){
					imgCenter = Robot.imgCenter;
					Robot.imgCenter = -1;
					rot = 0;
				}
			}
			
			Robot.drive.mecanumDrive_Polar(0,0,rot);
			
			try {
				java.lang.Thread.sleep(500);
			}
			catch (java.lang.InterruptedException ie){
					System.out.println(ie.toString());
				}
				
			//Robot.drive.mecanumDrive_Polar(0,0,0);
		
		}
		double turn = imgCenter - (resh/2);
		double turnAngle = (turn*68.5/resw);
		//System.out.println("Turn to Image Center "+ turn);
		System.out.println("TurnAngle to Image Center "+ turnAngle);
		System.out.println("Image Center "+ imgCenter);
		
		if (imgCenter==-1){
			rot = 0;
		}
		
		finished = false;
		Robot.drive.mecanumDrive_Polar(0,0,rot);
		//Robot.drive.mecanumDrive_Polar(.5,turn,0);
	}
	

	//public void isFinished(boolean fin) {
		//finished = fin;
		//return finished;
	//}
	
	public void end() {
		
	}

	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}
	
}