
package org.usfirst.frc.team3653.robot;

import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;

import org.usfirst.frc.team3653.robot.commands.AutoCenterGear;
import org.usfirst.frc.team3653.robot.commands.AutoLeft;
import org.usfirst.frc.team3653.robot.commands.AutoRight;
import org.usfirst.frc.team3653.robot.commands.DoNo;

import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.ADXRS450_Gyro;
import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.DigitalInput;
////import edu.wpi.first.wpilibj.TalonSRX;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.vision.VisionThread;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.cscore.UsbCamera;
import org.opencv.core.Rect;
import org.opencv.imgproc.Imgproc;
import org.usfirst.frc.team3653.robot.commands.VisionCommand;
import org.usfirst.frc.team3653.robot.subsystems.ExampleSubsystem;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {

	public static final ExampleSubsystem exampleSubsystem = new ExampleSubsystem();
	public static ADXRS450_Gyro gyro;
	private XboxController player1;
	public static RobotDrive drive;
	
	private Relay coolLED;
	private Relay camLED;
	private VisionThread visionT;
	public static double imgCenter = -1;
	public static final Object imgLock = new Object();
	private boolean bFieldDrive = false;
	private boolean bArcadeDriveReverse = false;
	////private TalonSRX agit;
	////private TalonSRX scotty;
	private VictorSP agit;
	private VictorSP shooter;
	private VictorSP scotty;
	private Compressor theCompressor;
	public static DoubleSolenoid theSolenoid;
	private DigitalInput theLimitSwitch;
	/* For autonomous */
	public static int drive_count;
	public static int drive_state;
	public static int drive_heading;
	public static int boiler_spin;
	
	private static final int RES_WIDTH = 320; // 640/2
	private static final int RES_HEIGHT = 240; // 480/2
	
	private static final int AUTO_STATE_DONE = 0;
	private static final int AUTO_STATE_LEFT = 1;
	private static final int AUTO_STATE_RIGHT = 2;
	private static final int AUTO_STATE_CENTER = 3;
	private static final int AUTO_STATE_CFWD = 4;
	private static final int AUTO_STATE_CDROP = 5;
	private static final int AUTO_STATE_CREV = 6;
	private static final int AUTO_STATE_CLAT = 7;
	private static final int AUTO_STATE_CEND = 8;
	private static final int AUTO_STATE_LSLANT = 9;
	private static final int AUTO_STATE_RSLANT = 10;
	//private static final int AUTO_STATE_LBOIL = 11;
	//private static final int AUTO_STATE_RBOIL = 12;
	


	//VisionCommand v = new VisionCommand();
	
	

	//Command autonomousCommand;
	SendableChooser<String> chooser = new SendableChooser<>();

	private boolean checkAspectRatio(Rect r){
		if (r.width==0){return false;}
		double ratt = (double)(r.height)/r.width;
		return 2.0 <= ratt && ratt <= 3.0;
	}
	private boolean checkSpacing(Rect r0, Rect r1){
		if (r0.height==0){return false;}
		double ratio = (Math.abs((double)(r0.x-r1.x)/r0.height));
		return 1.20<=ratio && ratio<=2.0;
		
	}
	
	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		coolLED = new Relay(1);
		theCompressor = new Compressor();
		theSolenoid = new DoubleSolenoid(0,1);
		theLimitSwitch = new DigitalInput(0);
		camLED = new Relay(0);
		gyro = new ADXRS450_Gyro(SPI.Port.kOnboardCS0);
		theCompressor.setClosedLoopControl(true);
		CameraServer.getInstance().startAutomaticCapture(0);
		
		chooser.addDefault("Default", "Default");
		chooser.addObject("AutoL", "AutoL");
		chooser.addObject("AutoR", "AutoR");
		chooser.addObject("AutoC", "AutoC");
		chooser.addObject("GearLeft", "GearLeft");
		chooser.addObject("RBoiler", "RBoiler");
		chooser.addObject("LBoiler", "LBoiler");
		SmartDashboard.putData("Auto mode", chooser);
		
		//theCompressor.start();
		
		/*
		UsbCamera camera =  CameraServer.getInstance().startAutomaticCapture(0);
		camera.setResolution(RES_WIDTH, RES_HEIGHT);
		camera.setFPS(10);
		
		visionT = new VisionThread(camera, new GripPipeline(), pipeline -> {
			if (pipeline.filterContoursOutput().size()==2){
					Rect r0 = Imgproc.boundingRect(pipeline.filterContoursOutput().get(0));
					Rect r1 = Imgproc.boundingRect(pipeline.filterContoursOutput().get(1));
					
					if (checkAspectRatio(r0)&& checkAspectRatio(r1)&&checkSpacing(r0,r1)){
							synchronized (imgLock){
							imgCenter = ((r0.x+r1.x+r1.width)/2);
						}
					} 
					
				}
			});
		visionT.start();
		*/
		
		//SmartDashboard.putData(value);
		
		//LiveWindow.addSensor("Vision", "gyro", gyro);
		player1 = new XboxController(0);

		drive = new RobotDrive(
						new VictorSP(0),   // Front Left
						new VictorSP(2), // Rear Left
						new VictorSP(3),   // Front Right
						new VictorSP(1) ); // Rear Right
		
		agit = new VictorSP(5);     //// TalonSRX(5);
		shooter = new VictorSP(6);
		scotty = new VictorSP(8);   //// TalonSRX(8);
		
		//SmartDashboard.putData("Gyro", gyro);
		//chooser.addDefault("Default Auto", new ExampleCommand());
		// chooser.addObject("My Auto", new MyAutoCommand());
	}

	/**
	 * This function is called once each time the robot enters Disabled mode.
	 * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
	 */
	@Override
	public void disabledInit() {
		//theCompressor.stop();
		theCompressor.setClosedLoopControl(false);
		
	}

	@Override
	public void disabledPeriodic() {
		//Scheduler.getInstance().run();
		coolLED.set(Relay.Value.kOff);
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * getString code to get the auto name from the text box below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the
	 * chooser code above (like the commented example) or additional comparisons
	 * to the switch structure below with additional strings & commands.
	 */
	@Override
	public void autonomousInit() {
		//VisionCommand vision = new VisionCommand();

		camLED.set(Relay.Value.kForward);
		System.out.println( "LED On" );
		theCompressor.setClosedLoopControl(true);
		drive_count = 0;
		drive_heading = 0;
		gyro.reset();
		
	System.out.println("autonoumousInit()");															
		
		//v.initialize();
	 String autoSelected = chooser.getSelected(); 
		System.out.println("autonoumousInit()" + autoSelected );
	 switch(autoSelected) { 
	 	case "AutoR": 
	 		System.out.println("AutoR()");	
	 		drive_state = AUTO_STATE_RIGHT;
	 		drive_heading = -60; //COMMENTED OUT FOR ORLANDO PLAYOFFS
	 		break; 
	 	case "AutoL":
	 		drive_state = AUTO_STATE_LEFT;
	 		drive_heading = +60; //COMMENTED OUT FOR ORLANDO PLAYOFFS
	 		break;
	 	case "AutoC":
	 		drive_state = AUTO_STATE_CENTER;
	 		break;
	 	case "Default":
	 	default:
	 		System.out.println("Default()");	
	 		drive_state = AUTO_STATE_DONE; 
	 		break;
	 	/**
	 	case "RBoiler":
	 		drive_state = AUTO_STATE_RBOIL;
	 		break;
	 	case "LBoiler":
	 		drive_state = AUTO_STATE_LBOIL;
	 		break;
	 		*/
	 	/*case "GearLeft":
	 		drive_state = ;*/
		}
		 

		// schedule the autonomous command (example)
		//if (autonomousCommand != null)
		//	autonomousCommand.start();		
	}

	/**
	 * This function is called periodically during autonomous
	 */
	@Override
	public void autonomousPeriodic() {
		
		double gyroangle = gyro.getAngle();
		
		double spin = 0;
		if (gyroangle < drive_heading - 1) {
			spin = 0.15;
		}
		else if (gyroangle > drive_heading + 1) {
			spin = -0.15;
		}
		
		switch(drive_state) {
		case AUTO_STATE_DONE:
			drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
			break;
		case AUTO_STATE_LEFT:
		case AUTO_STATE_RIGHT:
			
			/*FOR ORLANDO PLAYOFFS
			
			if (drive_count < 110) {
				
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, spin, -0.3, gyroangle );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				drive_count = 0;
				drive_state = AUTO_STATE_DONE;
				*/
			
			  if (drive_count <= 80) {
			 
				drive_count ++;
				drive.mecanumDrive_Cartesian( 0, 0, -0.3, 0 );
			}
			else if (drive_count > 80 && drive_count < 140 ) {
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, spin, -0.3, 0 );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				if(drive_state == AUTO_STATE_LEFT){
					drive_state = AUTO_STATE_LSLANT;
				}
				else{
					drive_state = AUTO_STATE_RSLANT;
				}
				drive_count = 0;
				
			}
			break;
		case AUTO_STATE_CENTER:
			if (drive_count < 110) {
			
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, spin, -0.3, gyroangle );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, -0.15, 0 );
				drive_count = 0;
				drive_state = AUTO_STATE_CDROP;
				
				/* //backup AUTO_STATE_CENTER (worked in SOFLA)
				 if (drive_count < 110) {
					drive_count++;
			    	drive.mecanumDrive_Cartesian( 0, 0, -0.3, 0 );			
				}
				else
				{
					drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
					drive_count = 0;
					drive_state = AUTO_STATE_CDROP;*/
				
				
			}
			break;
		case AUTO_STATE_CDROP:
			 final int stoppre=100;
			 final int stoppost=50;
			
			if (drive_count < stoppre) {
				// Pause before drop
				drive.mecanumDrive_Cartesian( 0.0, 0, -0.10, 0 );
				drive_count++;
			} else if (drive_count == stoppre) {
				Robot.theSolenoid.set(Value.kForward);
				drive_count++;
			} else if (drive_count < (stoppre+stoppost)) {
				// Pause after drop
				drive_count++;
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
			}
			else {
				drive_state = AUTO_STATE_CREV;
				drive_count = 0;
			}
			break;
		case AUTO_STATE_CREV:
			if (drive_count < 30) {
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, 0, +0.4, 0 );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				drive_state = AUTO_STATE_CLAT;
				drive_count = 0;
				
			}
			break;
		case AUTO_STATE_CLAT:
			if (drive_count < 150) {
				/* REMOVE IF ABOVE WORKS
				 double spin = 0;
				if (gyroangle < -1.0) {
					spin = 0.15;
				}
				else if (gyroangle > 1.0) {
					spin = -0.15;
				}*/ 
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0.8, spin, 0.0, gyroangle );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				drive_state = AUTO_STATE_CFWD;
				drive_count = 0;
			}
			break;
		case AUTO_STATE_CFWD:
			if (drive_count < 100) {
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, 0, -0.4, 0 );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				Robot.theSolenoid.set(Value.kReverse);
				drive_state = AUTO_STATE_DONE;
				drive_count = 0;
			}
			break;
		case AUTO_STATE_LSLANT:
		case AUTO_STATE_RSLANT:
			if (drive_count < 30) {
				drive_count++;
		    	drive.mecanumDrive_Cartesian( 0, spin, -0.2, drive_heading - gyroangle );			
			}
			else
			{
				drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
				drive_state = AUTO_STATE_DONE;
				drive_count = 0;
			}
			
			break;
		/*
		case AUTO_STATE_RBOIL:
			break;
		
		
		case AUTO_STATE_CEND:
			break;
			*/
		}
/*
		if (drive_count < 125) {
			drive_count++;
	    	drive.mecanumDrive_Cartesian( 0, 0, -0.4, 0 );			
		}
		else
		{
			drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
			
		}
*/	
		/*
		//v.execute();
		
		double center=-1;
		Scheduler.getInstance().run();
		synchronized (Robot.imgLock){
			if (Robot.imgCenter>=0){
				center= Robot.imgCenter;
				Robot.imgCenter = -1;
			}
			
		}
		if (center >=0){
		double turn = center - (Robot.RES_WIDTH/2);
		double turnAngle = (turn*68.5/Robot.RES_WIDTH);
		//System.out.println("Turn to Image Center "+ turn);
		System.out.println("TurnAngle to Image Center "+ turnAngle);
		System.out.println("Image Center "+ center);	
		}
		*/
	}

	@Override
	public void teleopInit() {
		// This makes sure that the autonomous stops running when
		// teleop starts running. If you want the autonomous to
		// continue until interrupted by another command, remove
		// this line or comment it out.
		drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
		//if (autonomousCommand != null)
			//autonomousCommand.cancel();
		theCompressor.setClosedLoopControl(true);
		
	}

	/**
	 * This function is called periodically during operator control
	 */
	@Override
	public void teleopPeriodic() {
		/****** DANGER - CLIMBING MOTOR WILL ONLY SPIN IN ONE DIRECTION *******/
		/****** VALUES PASSED TO scotty.setSpeed() MUST BE NEGATIVE     *******/
		/****** THE getTriggerAxis() RETURNS POSITIVE VALUES            *******/
		//blue/red led on
		coolLED.set(Relay.Value.kForward);
		
		// Beam me up Scotty
		double triggerValue = player1.getTriggerAxis( GenericHID.Hand.kLeft );
		/*
		if (triggerValue > 0.5){
			if (!theLimitSwitch.get()) {
				player1.setRumble( GenericHID.RumbleType.kLeftRumble, 0.5 );
				//scotty.setSpeed( 0.0 );
			} else {
				// Climb fast
				scotty.setSpeed(-triggerValue);
				player1.setRumble( GenericHID.RumbleType.kLeftRumble, 0.0 );
			}
		} else if (player1.getBumper(GenericHID.Hand.kLeft)){
			if (!theLimitSwitch.get()) {
				player1.setRumble( GenericHID.RumbleType.kLeftRumble, 0.5 );
				//scotty.setSpeed( 0.0 );
			} else {
				// Climb slow
				scotty.setSpeed(-0.5);
				player1.setRumble( GenericHID.RumbleType.kLeftRumble, 0.0 );
			}
		} */
		if (triggerValue>0.5){
			scotty.setSpeed(-triggerValue);
		}
		else {
			// Climb stop
			scotty.setSpeed(0);
			player1.setRumble( GenericHID.RumbleType.kLeftRumble, 0.0 );
		}
		
		// Shooter
		triggerValue = player1.getTriggerAxis( GenericHID.Hand.kRight );
		if (triggerValue > 0.5){
			// Shooter on
			shooter.setSpeed(1/*triggerValue*/);
			agit.setSpeed(+0.35);
		} else if (player1.getBumper(GenericHID.Hand.kRight)) {
			// Shooter reverse (in case of ball jam)
			shooter.setSpeed(-0.5);
			agit.setSpeed(-0.35);
		} else {
			// Shooter off
			shooter.setSpeed(0.0);
			agit.setSpeed(0.0);
		}
		
		if(player1.getAButton()){
			theSolenoid.set(DoubleSolenoid.Value.kForward);
		}
		else{
			theSolenoid.set(DoubleSolenoid.Value.kReverse);
		}
		/*
		else{
			theSolenoid.set(DoubleSolenoid.Value.kOff);
		}
		
		// Camera LED
		if (player1.getAButton()){
			camLED.set(Relay.Value.kForward);
		} else if (player1.getBButton()){
			camLED.set(Relay.Value.kOff);
		}
		Scheduler.getInstance().run();
    	LiveWindow.run();
*/
		/*
		System.out.format("Lx %+5.2f, Ly %+5.2f, Rx %+5.2f, Ry %+5.2f\n",
				player1.getX(GenericHID.Hand.kLeft),
				player1.getY(GenericHID.Hand.kLeft),
				player1.getX(GenericHID.Hand.kRight),
				player1.getY(GenericHID.Hand.kRight) );
		*/

		double angle = 0.0;
    	if (bFieldDrive){
    		angle = gyro.getAngle();
    	}
    	else if (bArcadeDriveReverse){
    		angle = 180.0;
    	}

    	GenericHID.Hand driveStick = GenericHID.Hand.kLeft;
    	GenericHID.Hand spinStick = GenericHID.Hand.kRight;
    	
    	double driveSensitivity = 1 ;
    	if (player1.getStickButton(driveStick)) {
    		driveSensitivity = 0.2;
    	}

    	double driveX = player1.getX(driveStick);
    	double driveY = player1.getY(driveStick);
    	double spin = player1.getX(spinStick);

    	 //dead zone calibration
    	if (Math.abs(driveX+0.03) < 0.05) {
    		driveX = 0.0;
    	}
    	if (Math.abs(driveY+0.03) < 0.05) {
    		driveY = 0.0;
    	}
    	if (Math.abs(spin-0.09) < 0.05) {
    		spin = 0.0;
    	}

    	drive.mecanumDrive_Cartesian(
				driveX * driveSensitivity,
				spin * driveSensitivity,
				driveY * driveSensitivity,
				angle );
	}

	/**
	 * This function is called periodically during test mode
	 */
	@Override
	public void testPeriodic() {
		
    	while(isTest()&& isEnabled()) {
    		double angle = gyro.getAngle();
    		LiveWindow.run();
    		System.out.println(angle);
    		Timer.delay(1);
    	}
	}
}
