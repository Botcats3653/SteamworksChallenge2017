package org.usfirst.frc.team3653.robot.commands;

import org.usfirst.frc.team3653.robot.Robot;

import edu.wpi.first.wpilibj.DoubleSolenoid.Value;
import edu.wpi.first.wpilibj.command.Command;

public class AutoCenterGear extends Command {
	public AutoCenterGear(){
		
	}
	
	public void execute() {
		if (Robot.drive_count < 25) {
			Robot.drive_count++;
	    	Robot.drive.mecanumDrive_Cartesian( 0, 0, -0.4, 0 );			
		}
		if (Robot.drive_count > 25 && Robot.drive_count < 30){
			Robot.drive_count++;
			Robot.drive.mecanumDrive_Cartesian (0,0,0,0);}
		if (Robot.drive_count >7 ){
			Robot.drive.mecanumDrive_Cartesian( 0.0, 0, 0.4, 0 );
		}
		else
		{
			Robot.drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
			Robot.theSolenoid.set(Value.kForward);
			
		}
		
	}

	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

}
