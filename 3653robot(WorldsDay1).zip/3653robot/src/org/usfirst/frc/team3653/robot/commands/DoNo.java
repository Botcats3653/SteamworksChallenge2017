package org.usfirst.frc.team3653.robot.commands;

import edu.wpi.first.wpilibj.command.Command;

public class DoNo extends Command {
	public DoNo() {
		
	}
	public void execute() {
		
	}

	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}
	

}
