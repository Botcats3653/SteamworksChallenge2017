package org.usfirst.frc.team3653.robot.commands;

import org.usfirst.frc.team3653.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

public class AutoRight extends Command {
	
	public AutoRight(){
		
		}
	public void execute() {
		if (Robot.drive_count < 100) {
			Robot.drive_count++;
	    	Robot.drive.mecanumDrive_Cartesian( 0, 0, -0.4, 0 );			
		}
		else
		{
			Robot.drive.mecanumDrive_Cartesian( 0.0, 0, 0, 0 );
			
		}
	}
	@Override
	protected boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
