package org.usfirst.frc.team3653.robot.commands;

import edu.wpi.first.wpilibj.command.Command;
//import edu.wpi.first.wpilibj.RobotDrive;
import org.usfirst.frc.team3653.robot.Robot;

public class VisionCommand extends Command{
	double  imgCenter;
	boolean finished;
	public VisionCommand() {
		finished = true;
	}
	public void initialize() {
		
	}
	public void execute() {
		synchronized (Robot.imgLock){
			imgCenter = Robot.imgCenter;
		}
		double turn = imgCenter - (Robot.RES_WIDTH/2);
		double turnAngle = (turn*68.5/Robot.RES_WIDTH);
		System.out.println("Turn to Image Center "+ turn);
		System.out.println("TurnAngle to Image Center "+ turnAngle);
		System.out.println("Image Center "+ imgCenter);
		finished = false;
		//Robot.drive.mecanumDrive_Polar(.5,turn,0);
	}
	

	public boolean isFinished() {
		return finished;
	}
	
	public void end() {
		
	}
	
}